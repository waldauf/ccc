-- Create this as 'lua/bedrock_keys.lua' in your Neovim config directory
-- Basically a re-creation of this bash script
-- profile="${1:-default}"
-- credentials="$(aws configure export-credentials --profile "$profile")"
-- access_key=$(jq -r '.AccessKeyId' <<<"$credentials")
-- secret_key=$(jq -r '.SecretAccessKey' <<<"$credentials")
-- session_token=$(jq -r '.SessionToken' <<<"$credentials")
-- region=$(aws configure get region --profile "$profile")
-- export BEDROCK_KEYS="$access_key,$secret_key,$region,$session_token"

-- Note: requires curl>=8.12, which resolves some bugs with aws

local M = {}

function M.set_bedrock_keys(profile)
  profile = profile or "rossum-dev" -- Zde si můžete nastavit svůj výchozí AWS profil

  local credentials_cmd = vim.system(
    { "aws", "configure", "export-credentials", "--profile", profile },
    { text = true }
  )
  local credentials = credentials_cmd:wait()

  if credentials.code ~= 0 then
    vim.notify("Chyba při získávání AWS credentials: " .. vim.trim(credentials.stderr), vim.log.levels.ERROR)
    return
  end

  local ok, cred_data = pcall(vim.json.decode, credentials.stdout)
  if not ok then
    vim.notify("Chyba při parsování JSON odpovědi z AWS CLI.", vim.log.levels.ERROR)
    return
  end

  -- Váš kolega měl region napevno, což je pro Bedrock běžné. Ponechávám to tak.
  local region_text = "us-west-2"

  vim.notify(
    string.format('AWS klíče úspěšně nastaveny pro profil "%s" v regionu "%s".', profile, region_text),
    vim.log.levels.INFO
  )

  return cred_data
end

return M
