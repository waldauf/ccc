-- Peek preview window for LSP locations in Neovim
-- https://github.com/DNLHC/glance.nvim
return {
  "dnlhc/glance.nvim",
  cmd = "Glance",
}
