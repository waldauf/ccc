return {
  "nvim-lualine/lualine.nvim",
  opts = function()
    -- Helper function to find the git repository root
    local function get_git_root()
      local git_root = vim.fn.system("git rev-parse --show-toplevel 2> /dev/null")
      if vim.v.shell_error ~= 0 then
        return nil
      end
      return vim.fn.trim(git_root)
    end

    -- The combined file path function
    local function file_path()
      local current_file = vim.fn.expand("%:p")
      local git_root = get_git_root()

      -- If in a git repo, show path relative to repo root
      if git_root and current_file:find(git_root, 1, true) then
        return current_file:sub(#git_root + 2)
      end

      -- Otherwise, show path relative to current working directory (like path = 1)
      return vim.fn.expand("%:p:.")
    end

    -- Your existing LazyVim opts table...
    local opts = {
      options = {
        theme = "auto",
        -- etc.
      },
      sections = {
        lualine_c = {
          LazyVim.lualine.root_dir(),
          {
            "diagnostics" --[[...]],
          },
          { "filetype", icon_only = true, separator = "", padding = { left = 1, right = 0 } },
          -- Replace the original path component with your new function
          { file_path },
        },
        -- ... other sections
      },
      extensions = { "neo-tree", "lazy", "fzf" },
    }

    return opts
  end,
}
