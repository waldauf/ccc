return {
  {
    "pimalaya/himalaya-vim",
    cmd = { "Himalaya" },
    init = function()
      vim.g.himalaya_executable = "himalaya" -- or full path
      -- optional extras if you use them:
      vim.g.himalaya_folder_picker = "fzflua"
      -- vim.g.himalaya_compose_autocmds = 1
    end,
  },
}
