return {
  "robitx/gp.nvim",
  config = function()
    local conf = {
      openai_api_key = os.getenv("OPENAI_API_KEY"),

      agents = {
        {
          provider = "openai", -- volitelné, ale dobré přidat
          name = "GPT-5.2",
          chat = true,
          command = true,
          model = { model = "gpt-5.2", temperature = 0.7 },
          system_prompt = require("gp.defaults").chat_system_prompt,
        },
      },

      -- nastav výchozí agenty podle jména
      default_chat_agent = "GPT-5.2",
      default_command_agent = "GPT-5.2",
    }

    require("gp").setup(conf)
  end,
}
