return {
  dir = vim.fn.stdpath("config") .. "/lua/plugins/rainbow-brackets",
  name = "rainbow-brackets",
  lazy = false,
  priority = 1000,
  config = function()
    require("rainbow-brackets").setup()
  end,
}
