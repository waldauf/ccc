return {
  "folke/noice.nvim",
  opts = {
    presets = {
      lsp_doc_border = true, -- border pro LSP hover/signature
    },
  },
}
