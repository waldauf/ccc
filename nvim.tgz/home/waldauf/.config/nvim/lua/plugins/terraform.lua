return {
  -- LSP Server for Terraform
  {
    "neovim/nvim-lspconfig",
    opts = {
      servers = {
        terraformls = {}, -- Enable Terraform language server
      },
    },
  },

  -- Mason to ensure tflint is installed
  {
    "mason-org/mason.nvim",
    opts = {
      ensure_installed = { "tflint" },
    },
  },

  -- Optional: null-ls integration for formatting and validation
  {
    "nvimtools/none-ls.nvim",
    optional = true,
    opts = function(_, opts)
      local null_ls = require("null-ls")
      opts.sources = vim.list_extend(opts.sources or {}, {
        null_ls.builtins.formatting.terraform_fmt,
        null_ls.builtins.diagnostics.terraform_validate,
      })
    end,
  },

  -- Optional: nvim-lint for terraform_validate linting
  {
    "mfussenegger/nvim-lint",
    optional = true,
    opts = {
      linters_by_ft = {
        terraform = { "terraform_validate" },
        tf = { "terraform_validate" },
      },
    },
  },

  -- Optional: conform.nvim for formatting Terraform files
  {
    "stevearc/conform.nvim",
    optional = true,
    opts = {
      formatters_by_ft = {
        terraform = { "terraform_fmt" },
        tf = { "terraform_fmt" },
        ["terraform-vars"] = { "terraform_fmt" },
      },
    },
  },
}
