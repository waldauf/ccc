return {
  "ibhagwan/fzf-lua",
  opts = function(_, opts)
    opts.winopts = vim.tbl_deep_extend("force", opts.winopts or {}, {
      fullscreen = false,
      preview = {
        layout = "vertical",
        vertical = "up:65%",
        horizontal = "right:50%",
      },
    })

    opts.files = vim.tbl_deep_extend("force", opts.files or {}, {
      rg_opts = [[--color=never --files --follow -g "!.git"]],
    })

    -- Merge into existing file actions (preserves LazyVim defaults like ctrl-r, ctrl-t)
    opts.actions = opts.actions or {}
    opts.actions.files = opts.actions.files or {}
    opts.actions.files["enter"] = function(selected, o)
      if #selected > 1 then
        for _, file in ipairs(selected) do
          local f = require("fzf-lua.path").entry_to_file(file, o)
          vim.cmd("edit " .. vim.fn.fnameescape(f.path))
        end
      else
        require("fzf-lua.actions").file_edit(selected, o)
      end
    end
  end,
}
