local M = {}

local ns = vim.api.nvim_create_namespace("rainbow_brackets")

local colors = {
  "#e06c75",
  "#e5c07b",
  "#61afef",
  "#d19a66",
  "#98c379",
  "#c678dd",
  "#56b6c2",
}

local pairs_map = {
  ["("] = ")",
  ["["] = "]",
  ["{"] = "}",
}
local openers = { ["("] = true, ["["] = true, ["{"] = true }
local closers = { [")"] = true, ["]"] = true, ["}"] = true }

local function define_highlights()
  for i, color in ipairs(colors) do
    vim.api.nvim_set_hl(0, "RainbowBracket" .. i, { fg = color, default = true })
  end
  vim.api.nvim_set_hl(0, "RainbowBracketError", { fg = "#ff0000", bold = true, default = true })
end

local function highlight_buffer(bufnr)
  bufnr = bufnr or vim.api.nvim_get_current_buf()
  if not vim.api.nvim_buf_is_valid(bufnr) then
    return
  end

  vim.api.nvim_buf_clear_namespace(bufnr, ns, 0, -1)

  local lines = vim.api.nvim_buf_get_lines(bufnr, 0, -1, false)
  local stack = {}
  local in_string = false
  local string_char = nil

  for lnum, line in ipairs(lines) do
    local col = 1
    local prev_char = ""
    while col <= #line do
      local ch = line:sub(col, col)

      if in_string then
        if ch == string_char and prev_char ~= "\\" then
          in_string = false
          string_char = nil
        end
      else
        if ch == '"' or ch == "'" then
          in_string = true
          string_char = ch
        elseif openers[ch] then
          table.insert(stack, { char = ch, line = lnum - 1, col = col - 1 })
          local depth = #stack
          local hl = "RainbowBracket" .. (((depth - 1) % #colors) + 1)
          vim.api.nvim_buf_set_extmark(bufnr, ns, lnum - 1, col - 1, {
            end_col = col,
            hl_group = hl,
            priority = 110,
          })
        elseif closers[ch] then
          local top = stack[#stack]
          if top and pairs_map[top.char] == ch then
            local depth = #stack
            local hl = "RainbowBracket" .. (((depth - 1) % #colors) + 1)
            vim.api.nvim_buf_set_extmark(bufnr, ns, lnum - 1, col - 1, {
              end_col = col,
              hl_group = hl,
              priority = 110,
            })
            table.remove(stack)
          else
            vim.api.nvim_buf_set_extmark(bufnr, ns, lnum - 1, col - 1, {
              end_col = col,
              hl_group = "RainbowBracketError",
              priority = 110,
            })
          end
        end
      end

      prev_char = ch
      col = col + 1
    end
    in_string = false
    string_char = nil
  end
end

local enabled_buffers = {}

local function enable_buffer(bufnr)
  bufnr = bufnr or vim.api.nvim_get_current_buf()
  if enabled_buffers[bufnr] then
    highlight_buffer(bufnr)
    return
  end
  enabled_buffers[bufnr] = true

  vim.api.nvim_buf_attach(bufnr, false, {
    on_lines = vim.schedule_wrap(function()
      if enabled_buffers[bufnr] and vim.api.nvim_buf_is_valid(bufnr) then
        highlight_buffer(bufnr)
      end
    end),
    on_detach = function()
      enabled_buffers[bufnr] = nil
    end,
  })

  highlight_buffer(bufnr)
end

local function disable_buffer(bufnr)
  bufnr = bufnr or vim.api.nvim_get_current_buf()
  enabled_buffers[bufnr] = nil
  if vim.api.nvim_buf_is_valid(bufnr) then
    vim.api.nvim_buf_clear_namespace(bufnr, ns, 0, -1)
  end
end

local excluded_filetypes = {
  ["snacks_dashboard"] = true,
  ["dashboard"] = true,
  ["lazy"] = true,
  ["mason"] = true,
  ["neo-tree"] = true,
  ["NvimTree"] = true,
  ["TelescopePrompt"] = true,
  ["noice"] = true,
  [""] = false,
}

function M.setup(opts)
  opts = opts or {}
  if opts.colors then
    colors = opts.colors
  end

  define_highlights()

  vim.api.nvim_create_autocmd("ColorScheme", {
    callback = define_highlights,
  })

  vim.api.nvim_create_autocmd({ "BufReadPost", "BufNewFile", "BufEnter" }, {
    callback = function(args)
      local ft = vim.bo[args.buf].filetype
      local bt = vim.bo[args.buf].buftype
      if excluded_filetypes[ft] or bt == "nofile" or bt == "prompt" then
        return
      end
      enable_buffer(args.buf)
    end,
  })

  vim.api.nvim_create_user_command("RainbowBracketsToggle", function()
    local bufnr = vim.api.nvim_get_current_buf()
    if enabled_buffers[bufnr] then
      disable_buffer(bufnr)
    else
      enable_buffer(bufnr)
    end
  end, {})

  vim.api.nvim_create_user_command("RainbowBracketsOn", function()
    enable_buffer(vim.api.nvim_get_current_buf())
  end, {})

  vim.api.nvim_create_user_command("RainbowBracketsOff", function()
    disable_buffer(vim.api.nvim_get_current_buf())
  end, {})
end

return M

