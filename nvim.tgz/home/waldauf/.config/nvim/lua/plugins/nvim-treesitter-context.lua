return {
  "nvim-treesitter/nvim-treesitter-context",
  config = function()
    require("treesitter-context").setup({
      -- optional configuration here or leave empty for defaults
      enable = true, -- Enable the plugin
      max_lines = 0, -- No limit on context lines shown
      multiline_threshold = 5, -- Maximum lines to show for one context
      mode = "cursor", -- Context calculated based on current cursor line
      line_numbers = true, -- Show line numbers in context window
      separator = nil, -- Separator between context and source lines (optional)
      -- other options available, see full config in attached file
    })
  end,
  dependencies = { "nvim-treesitter/nvim-treesitter" }, -- treesitter is required
}
