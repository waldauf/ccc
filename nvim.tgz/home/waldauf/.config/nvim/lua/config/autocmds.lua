-- Autocmds are automatically loaded on the VeryLazy event
-- Default autocmds that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/autocmds.lua
--
-- Add any additional autocmds here
-- with `vim.api.nvim_create_autocmd`
--
-- Or remove existing autocmds by their group name (which is prefixed with `lazyvim_` for the defaults)
-- e.g. vim.api.nvim_del_augroup_by_name("lazyvim_wrap_spell")

-- Set global tab and indentation settings
vim.opt.tabstop = 2 -- Number of spaces a <Tab> character represents
vim.opt.shiftwidth = 2 -- Number of spaces for each indentation level
vim.opt.softtabstop = 2 -- Number of spaces for a <Tab> when editing
vim.opt.expandtab = true -- Use spaces instead of tabs

-- Per tmux-pane session save/restore
local function tmux_session_file()
  local tmux = vim.env.TMUX
  if not tmux then return nil end
  local session = vim.fn.system("tmux display-message -p '#S:#I.#P'"):gsub("%s+", "")
  local cwd = vim.fn.getcwd():gsub("/", "%%")
  local dir = vim.fn.stdpath("state") .. "/sessions"
  vim.fn.mkdir(dir, "p")
  return dir .. "/" .. cwd .. "_tmux_" .. session .. ".vim"
end

vim.api.nvim_create_autocmd("VimLeavePre", {
  callback = function()
    local f = tmux_session_file()
    if f then
      vim.cmd("mksession! " .. vim.fn.fnameescape(f))
    end
  end,
})

vim.api.nvim_create_autocmd("VimEnter", {
  callback = function()
    if vim.fn.argc() > 0 then return end
    local f = tmux_session_file()
    if f and vim.fn.filereadable(f) == 1 then
      vim.cmd("silent! source " .. vim.fn.fnameescape(f))
    end
  end,
  nested = true,
})
