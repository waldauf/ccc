-- Options are automatically loaded before lazy.nvim startup
-- Default options that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/options.lua
-- Add any additional options here

-- turn of relative number
-- vim.opt.relativenumber = false

-- make diff splits vertical by default
vim.o.diffopt = vim.o.diffopt .. ",vertical"

-- border for LSP floating windows (hover, signature help, diagnostics)
vim.diagnostic.config({ float = { border = "rounded" } })

-- Relativně ztmavit floating windows oproti aktuálnímu colorscheme
vim.api.nvim_create_autocmd("ColorScheme", {
  callback = function()
    local normal = vim.api.nvim_get_hl(0, { name = "Normal" })
    local bg = normal.bg or 0x282828 -- fallback pro transparent mode (gruvbox bg0)

    local factor = 0.8 -- ztmavit o 20%
    local r = math.floor(bit.rshift(bit.band(bg, 0xFF0000), 16) * factor)
    local g = math.floor(bit.rshift(bit.band(bg, 0x00FF00), 8) * factor)
    local b = math.floor(bit.band(bg, 0x0000FF) * factor)
    local darker = string.format("#%06x", bit.bor(bit.lshift(r, 16), bit.lshift(g, 8), b))

    vim.api.nvim_set_hl(0, "NormalFloat", { bg = darker })
    vim.api.nvim_set_hl(0, "FloatBorder", { bg = darker, fg = "#665c54" })
    vim.api.nvim_set_hl(0, "NoicePopup", { bg = darker })
    vim.api.nvim_set_hl(0, "NoicePopupBorder", { bg = darker, fg = "#665c54" })
  end,
})
