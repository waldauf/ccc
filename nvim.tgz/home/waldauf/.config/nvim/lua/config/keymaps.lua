-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here

vim.opt.clipboard:append("unnamedplus")
vim.keymap.set("v", "<C-c>", '"+y', { noremap = true, silent = true })
vim.keymap.set("n", "<C-v>", '"+p', { noremap = true, silent = true })

-- Define map variable
local map = vim.keymap.set

-- keymaps.lua
local map = vim.keymap.set

-- Grep words selceted or marked with *
local map = vim.keymap.set

-- Grep selected text or last search pattern
-- Press * on a word → <leader>s* (grep that word)
-- Select text visually → <leader>s* (grep that selection)
map({ "n", "v" }, "<leader>s*", function()
  local search_text = ""

  -- Check if in visual mode
  local mode = vim.fn.mode()
  if mode == "v" or mode == "V" or mode == "\22" then -- \22 is <C-v>
    -- Get visual selection
    vim.cmd('noau normal! "vy"')
    search_text = vim.fn.getreg("v")
    search_text = search_text:gsub("\n", " "):gsub("^%s+", ""):gsub("%s+$", "")
  else
    -- Normal mode: get last search pattern
    search_text = vim.fn.getreg("/")
    search_text = search_text:gsub("\\<", ""):gsub("\\>", "")
  end

  if search_text == "" then
    vim.notify("No text to search", vim.log.levels.WARN)
    return
  end

  require("fzf-lua").live_grep({
    search = search_text,
  })
end, { desc = "Grep selected/marked text" })

-- Multi-Select Files Then Grep
-- Press <leader>fs
-- Search for "<file_pattern>"
-- Press Tab to mark multiple files
-- Press Enter when done selecting
-- Now type "<searched_string>" to grep only in those selected files
map("n", "<leader>fs", function()
  require("fzf-lua").files({
    prompt = "Files (Tab=mark | Alt-a=all | Alt-c=clear | Enter=grep)> ",
    fzf_opts = {
      ["--bind"] = "alt-a:select-all,alt-c:deselect-all,alt-t:toggle-all",
    },
    actions = {
      ["default"] = function(selected)
        if #selected == 0 then
          vim.notify("No files selected", vim.log.levels.WARN)
          return
        end

        local files = {}
        local cwd = vim.fn.getcwd()

        for _, entry in ipairs(selected) do
          local file = require("fzf-lua.path").entry_to_file(entry)
          local abs_path = file.path

          -- Make absolute
          if not vim.startswith(abs_path, "/") then
            abs_path = cwd .. "/" .. abs_path
          end

          -- Normalize
          abs_path = vim.fn.fnamemodify(abs_path, ":p")

          if vim.fn.filereadable(abs_path) == 1 then
            table.insert(files, abs_path)
          end
        end

        if #files == 0 then
          vim.notify("No valid files selected", vim.log.levels.WARN)
          return
        end

        -- Create temporary file list
        local tmpfile = vim.fn.tempname()
        local f = io.open(tmpfile, "w")
        if f then
          for _, filepath in ipairs(files) do
            f:write(filepath .. "\n")
          end
          f:close()
        end

        -- Grep using file list
        require("fzf-lua").live_grep({
          cmd = string.format(
            "cat %s | xargs -d '\\n' rg --column --line-number --no-heading --color=always --smart-case -e",
            vim.fn.shellescape(tmpfile)
          ),
          prompt = string.format("Grep in %d file(s)> ", #files),
          -- Clean up tmpfile after closing
          fzf_opts = {
            ["--bind"] = string.format("close:execute-silent(rm %s)", vim.fn.shellescape(tmpfile)),
          },
        })
      end,
    },
  })
end, { desc = "Select files → grep" })

-- Copy to clipboard by Enter key
map("v", "<CR>", '"+y', { desc = "Copy to clipboard" })

-- Move buffer position left/right
map("n", "<leader>b<", ":BufferLineMovePrev<CR>", { desc = "Move buffer left" })
map("n", "<leader>b>", ":BufferLineMoveNext<CR>", { desc = "Move buffer right" })

-- Move lines up/down with leader
vim.keymap.set("n", "<leader>j", ":m .+1<CR>==", { desc = "Move line down" })
vim.keymap.set("n", "<leader>k", ":m .-2<CR>==", { desc = "Move line up" })
vim.keymap.set("v", "<leader>j", ":m '>+1<CR>gv=gv", { desc = "Move selection down" })
vim.keymap.set("v", "<leader>k", ":m '<-2<CR>gv=gv", { desc = "Move selection up" })

-- Duplicate line or selection
vim.keymap.set("n", "<leader>J", ":t.<CR>", { desc = "Duplicate line down" })
vim.keymap.set("n", "<leader>K", ":t.-1<CR>", { desc = "Duplicate line up" })
vim.keymap.set("v", "<leader>J", ":t.<CR>gv", { desc = "Duplicate line down" })
vim.keymap.set("v", "<leader>K", ":m .-1<CR>gv", { desc = "Move line up" })

--- SWITCH FZF-LUA LAYOUT ---
-- vertical layout (preview below)
vim.keymap.set("n", "<leader>fv", function()
  require("fzf-lua").live_grep({
    winopts = {
      preview = { layout = "vertical", vertical = "up:70%" },
    },
  })
end)

-- horizontal layout (preview right)
vim.keymap.set("n", "<leader>fh", function()
  require("fzf-lua").live_grep({
    winopts = {
      preview = { layout = "horizontal", horizontal = "right:70%" },
    },
  })
end)
-----------------------------

-- Delete all buffers
map("n", "<leader>bA", function()
  local current = vim.api.nvim_get_current_buf()
  for _, buf in ipairs(vim.api.nvim_list_bufs()) do
    if vim.api.nvim_buf_is_loaded(buf) then
      vim.api.nvim_buf_delete(buf, { force = false })
    end
  end
end, { desc = "Delete all buffers" })
------------------------------

--- ADD TO FILE and GREP SEARCH IN BUFFER's DIR ---
-- Files in current buffer's directory
map("n", "<leader>fB", function()
  require("fzf-lua").files({
    cwd = vim.fn.expand("%:p:h"),
  })
end, { desc = "Files in buffer dir" })

-- Grep in current buffer's directory
map("n", "<leader>sB", function()
  require("fzf-lua").live_grep({
    cwd = vim.fn.expand("%:p:h"),
  })
end, { desc = "Grep in buffer dir" })

-- Git files in current buffer's directory (if in git repo)
map("n", "<leader>fG", function()
  require("fzf-lua").git_files({
    cwd = vim.fn.expand("%:p:h"),
  })
end, { desc = "Git files in buffer dir" })
------------------------------

--- COPY BUFFER's PATH WITH FILENAME ---
map("n", "<leader>bY", function()
  local file_path = vim.fn.expand("%:p")
  local git_root = vim.fn.systemlist("git -C " .. vim.fn.expand("%:p:h") .. " rev-parse --show-toplevel")[1]

  if vim.v.shell_error == 0 and git_root then
    -- File is in git repo: copy relative path from git root
    local relative_path = file_path:gsub("^" .. vim.pesc(git_root) .. "/", "")
    vim.fn.setreg("+", relative_path)
    vim.notify("Copied (git): " .. relative_path, vim.log.levels.INFO)
  else
    -- File is not in git repo: copy full absolute path
    vim.fn.setreg("+", file_path)
    vim.notify("Copied (full): " .. file_path, vim.log.levels.INFO)
  end
end, { desc = "Copy file path (git relative or full)" })
------------------------------

-- Copy filename only
map("n", "<leader>by", function()
  local filename = vim.fn.expand("%:t")
  vim.fn.setreg("+", filename)
  vim.notify("Copied filename: " .. filename, vim.log.levels.INFO)
end, { desc = "Copy filename" })
------------------------------

-- Remove trailing whitespace
map("n", "<leader>cw", function()
  local pos = vim.api.nvim_win_get_cursor(0)
  vim.cmd([[%s/\s\+$//e]])
  vim.api.nvim_win_set_cursor(0, pos)
  vim.notify("Trailing whitespace removed", vim.log.levels.INFO)
end, { desc = "Remove trailing whitespace" })
------------------------------

--- Open files from picked up commit -------------------------
-- Helper: vyber commit přes FZF a zavolej callback s jeho SHA
local function pick_commit(callback)
  local buf_dir = vim.fn.expand("%:p:h")
  if buf_dir == "" then
    buf_dir = vim.fn.getcwd()
  end
  local git_root =
    vim.fn.systemlist(string.format("git -C %s rev-parse --show-toplevel", vim.fn.shellescape(buf_dir)))[1]
  if vim.v.shell_error ~= 0 then
    vim.notify("Not a git repository", vim.log.levels.ERROR)
    return
  end

  require("fzf-lua").fzf_exec("git log --oneline --no-merges -50", {
    prompt = "Select commit> ",
    cwd = git_root,
    actions = {
      ["default"] = function(selected)
        if not selected or #selected == 0 then
          return
        end
        local sha = selected[1]:match("^(%S+)")
        if sha then
          callback(sha, git_root)
        end
      end,
    },
  })
end

-- Otevři soubory z commitu pomocí FZF picker
map("n", "<leader>go", function()
  pick_commit(function(commit, git_root)
    local files = vim.fn.systemlist(
      string.format("git -C %s diff-tree --no-commit-id --name-only -r %s", vim.fn.shellescape(git_root), commit)
    )

    if vim.v.shell_error ~= 0 or #files == 0 then
      vim.notify("No files found", vim.log.levels.WARN)
      return
    end

    require("fzf-lua").fzf_exec(files, {
      prompt = "Select files to open (Tab=toggle, Alt-a=all)> ",
      fzf_opts = { ["--multi"] = true },
      actions = {
        ["default"] = function(selected)
          for _, file in ipairs(selected) do
            vim.cmd("edit " .. vim.fn.fnameescape(git_root .. "/" .. file))
          end
        end,
      },
    })
  end)
end, { desc = "Open files from commit" })
------------------------------

-- Otevři všechny soubory z vybraného commitu
map("n", "<leader>gO", function()
  pick_commit(function(commit, git_root)
    local files = vim.fn.systemlist(
      string.format("git -C %s diff-tree --no-commit-id --name-only -r %s", vim.fn.shellescape(git_root), commit)
    )

    if vim.v.shell_error ~= 0 or #files == 0 then
      vim.notify("No files found", vim.log.levels.WARN)
      return
    end

    for _, file in ipairs(files) do
      if file ~= "" then
        vim.cmd("edit " .. vim.fn.fnameescape(git_root .. "/" .. file))
      end
    end

    vim.notify(string.format("Opened %d files from commit %s", #files, commit))
  end)
end, { desc = "Open all files from commit" })
------------------------------

-- Toggle absolute/relative line numbers for ALL buffers (including not yet visible)
-- Smaž původní LazyVim/Snacks toggle mappingy
vim.keymap.del("n", "<leader>ul")

local _rnu_override = nil
local _rnu_augroup = vim.api.nvim_create_augroup("RnuOverride", { clear = true })

map("n", "<leader>ul", function()
  local new_rnu = not vim.wo.relativenumber
  _rnu_override = new_rnu

  -- Nastav pro všechna aktuálně viditelná okna
  for _, win in ipairs(vim.api.nvim_list_wins()) do
    local buf = vim.api.nvim_win_get_buf(win)
    if vim.bo[buf].buflisted then
      vim.api.nvim_set_option_value("relativenumber", new_rnu, { win = win })
    end
  end

  -- Autocmd pro buffery, které se teprve otevřou/zobrazí
  vim.api.nvim_clear_autocmds({ group = _rnu_augroup })
  vim.api.nvim_create_autocmd("BufWinEnter", {
    group = _rnu_augroup,
    callback = function()
      if _rnu_override ~= nil and vim.bo.buflisted then
        vim.wo.relativenumber = _rnu_override
      end
    end,
  })

  vim.notify(new_rnu and "Relative numbers ON" or "Absolute numbers ON")
end, { desc = "Toggle line numbers (all buffers)" })
